import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class FlappyBird extends JPanel implements ActionListener, KeyListener {

    int frameWidth = 360;
    int frameHeight = 640;
    Image backgroundImage;
    Image birdImage;
    Image lowerPipeImage;
    Image upperPipeImage;

    // player
    int playerStartPosX = frameWidth / 8;
    int playerStartPosY = frameHeight / 2;
    int playerWidth = 34;
    int playerHeight = 24;
    Player player;

    // attribute pipe
    int pipeStartPosX = frameWidth;
    int pipeStartPosY = 0;
    int pipeWidth = 64;
    int pipeHeight = 512;
    ArrayList<Pipe> pipes;
    int pipePairCounter = 0;

    // game logic
    Timer gameLoop;
    Timer pipesCooldown;
    int gravity = 1;
    boolean gameOver = false;

    // score
    int score = 0;
    JLabel scoreLabel;

    // constructor
    public FlappyBird(){
        setPreferredSize(new Dimension(frameWidth, frameHeight));
        setFocusable(true);
        addKeyListener(this);
        setLayout(null);
        //setBackground(Color.blue);

        // load images
        backgroundImage = new ImageIcon(getClass().getResource("assets/background.png")).getImage();
        birdImage = new ImageIcon(getClass().getResource("assets/bird.png")).getImage();
        lowerPipeImage = new ImageIcon(getClass().getResource("assets/lowerPipe.png")).getImage();
        upperPipeImage = new ImageIcon(getClass().getResource("assets/upperPipe.png")).getImage();

        // setup score label
        scoreLabel = new JLabel("Score: 0");
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 20));
        scoreLabel.setForeground(Color.WHITE);
        scoreLabel.setBounds(10, 10, 150, 30);
        add(scoreLabel);

        startGame();
    }

    public void startGame() {
        gameOver = false;
        score = 0;
        scoreLabel.setText("Score: 0");

        player = new Player(playerStartPosX, playerStartPosY, playerWidth, playerHeight, birdImage);
        pipes = new ArrayList<Pipe>();

        if (pipesCooldown != null) {
            pipesCooldown.stop();
        }

        pipesCooldown = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!gameOver) {
                    placePipes();
                }
            }
        });
        pipesCooldown.start();

        if (gameLoop != null) {
            gameLoop.stop();
        }

        gameLoop = new Timer(1000/60, this);
        gameLoop.start();
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, this);
        g.drawImage(player.getImage(), player.getPosX(), player.getPosY(), player.getWidth(), player.getHeight(), this);

        for (Pipe pipe : pipes){
            g.drawImage(pipe.getImage(), pipe.getPosX(), pipe.getPosY(), pipe.getWidth(), pipe.getHeight(), this);
        }

        // Display game over message
        if (gameOver) {
            g.setColor(new Color(0, 0, 0, 150)); // semi-transparent black
            g.fillRect(0, 0, frameWidth, frameHeight);

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 30));
            String gameOverText = "Game Over";
            int textWidth = g.getFontMetrics().stringWidth(gameOverText);
            g.drawString(gameOverText, (frameWidth - textWidth) / 2, frameHeight / 2 - 30);

            g.setFont(new Font("Arial", Font.PLAIN, 20));
            String restartText = "Press 'R' to restart";
            textWidth = g.getFontMetrics().stringWidth(restartText);
            g.drawString(restartText, (frameWidth - textWidth) / 2, frameHeight / 2 + 10);

            g.setFont(new Font("Arial", Font.BOLD, 24));
            String finalScoreText = "Score: " + score;
            textWidth = g.getFontMetrics().stringWidth(finalScoreText);
            g.drawString(finalScoreText, (frameWidth - textWidth) / 2, frameHeight / 2 + 50);
        }
    }

    public void draw(Graphics g){
        g.drawImage(backgroundImage, 0, 0, frameWidth, frameHeight, null);

        g.drawImage(player.getImage(), player.getPosX(), player.getPosY(), player.getWidth(), player.getHeight(), null);

        for (int i = 0; 1 < pipes.size(); i++){
            Pipe pipe = pipes.get(i);
            g.drawImage(pipe.getImage(), pipe.getPosX(), pipe.getPosY(), pipe.getWidth(), pipe.getHeight(),null);
        }
    }

    Set<Integer> scoredPairs = new HashSet<>();

    public void move(){
        if (gameOver) return;

        player.setVelocityY(player.getVelocityY() + gravity);
        player.setPosY(player.getPosY() + player.getVelocityY());
        player.setPosY(Math.max(player.getPosY(), 0));

        // Check for bottom collision
        if (player.getPosY() + player.getHeight() >= frameHeight) {
            gameOver();
            return;
        }

        // Move pipes and check for collisions & scoring
        for (int i = 0; i < pipes.size(); i++){
            Pipe pipe = pipes.get(i);
            pipe.setPosX(pipe.getPosX() - 2);

            // Check for collision with pipe
            if (checkCollision(player, pipe)) {
                gameOver();
                return;
            }

            // Check if player passed the pipe
            if (!pipe.getPassed() && pipe.getPosX() + pipe.getWidth() < player.getPosX()) {
                pipe.setPassed(true);

                int currentPairId = pipe.getPipeId();
                if (!scoredPairs.contains(currentPairId)) {
                    score++;
                    scoreLabel.setText("Score: " + score);
                    scoredPairs.add(currentPairId);
                }
            }

        }

        pipes.removeIf(pipe -> pipe.getPosX() + pipe.getWidth() < 0);
    }

    private boolean checkCollision(Player player, Pipe pipe) {

        return player.getPosX() < pipe.getPosX() + pipe.getWidth() &&
                player.getPosX() + player.getWidth() > pipe.getPosX() &&
                player.getPosY() < pipe.getPosY() + pipe.getHeight() &&
                player.getPosY() + player.getHeight() > pipe.getPosY();
    }

    private void gameOver() {
        gameOver = true;
    }

    public void placePipes(){
        int randomPosY = -pipeHeight + (int)(Math.random() * 250);
        int openingSpace = frameHeight/4;

        Pipe upperPipe = new Pipe(pipeStartPosX, randomPosY, pipeWidth, pipeHeight, upperPipeImage);
        Pipe lowerPipe = new Pipe(pipeStartPosX, (randomPosY + openingSpace + pipeHeight), pipeWidth, pipeHeight, lowerPipeImage);

        upperPipe.setPipeId(pipePairCounter);
        lowerPipe.setPipeId(pipePairCounter);

        pipes.add(upperPipe);
        pipes.add(lowerPipe);

        pipePairCounter++;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        move();
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e){

    }

    @Override
    public void keyPressed(KeyEvent e){
        if (e.getKeyCode() == KeyEvent.VK_SPACE){
            player.setVelocityY(-10);
        } else if (e.getKeyCode() == KeyEvent.VK_R && gameOver) {
            startGame();
        }
    }

    @Override
    public void keyReleased(KeyEvent e){

    }
}