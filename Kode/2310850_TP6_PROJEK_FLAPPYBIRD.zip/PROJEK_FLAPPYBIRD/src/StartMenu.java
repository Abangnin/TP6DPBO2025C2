import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartMenu extends JFrame {

    private JPanel mainPanel;
    private JButton startButton;
    private JLabel titleLabel;
    private JPanel contentPanel;

    public StartMenu() {
        // Setup frame properties
        setTitle("Flappy Bird");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(360, 640);
        setLocationRelativeTo(null);
        setResizable(false);

        // Initialize components
        initComponents();

        // Set content pane
        setContentPane(mainPanel);
    }

    private void initComponents() {
        // Main panel with background
        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Load and draw background image
                try {
                    Image backgroundImage = new ImageIcon(getClass().getResource("assets/background.png")).getImage();
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                } catch (Exception e) {
                    // Fallback if image not found
                    setBackground(Color.CYAN);
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };

        // Using GridBagLayout to position components similar to the image
        mainPanel.setLayout(new GridBagLayout());

        // Content panel to hold title and button (transparent)
        contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setOpaque(false);

        // Title label
        titleLabel = new JLabel("WELCOME TO FLAPPYBIRD");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Start button with dark background
        startButton = new JButton("START GAME");
        startButton.setFont(new Font("Arial", Font.BOLD, 16));
        startButton.setForeground(Color.WHITE);
        startButton.setBackground(new Color(30, 30, 30));
        startButton.setFocusPainted(false);
        startButton.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        startButton.setPreferredSize(new Dimension(150, 40));

        // Add action listener to start button
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGame();
            }
        });

        // Add components to content panel with proper spacing
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Add title
        contentPanel.add(titleLabel, gbc);

        // Add vertical spacer
        gbc.weighty = 0.2;
        gbc.fill = GridBagConstraints.BOTH;
        contentPanel.add(Box.createVerticalStrut(20), gbc);

        // Reset weight for button
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;

        // Add start button
        contentPanel.add(startButton, gbc);

        // Add content panel to main panel
        mainPanel.add(contentPanel);
    }

    private void startGame() {
        // Close this menu
        dispose();

        // Start the game
        JFrame frame = new JFrame("Flappy Bird");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(360, 640);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);

        FlappyBird flappyBird = new FlappyBird();
        frame.add(flappyBird);
        frame.pack();
        flappyBird.requestFocus();
        frame.setVisible(true);
    }
}
